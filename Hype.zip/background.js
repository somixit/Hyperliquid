const DEXSCREENER_API_URL =
  "https://api.dexscreener.io/latest/dex/pairs/hyperliquid/0x13ba5fea7078ab3798fbce53b4d0721c";

// Función para obtener el timestamp con hora, minuto y segundo
function getTimestamp() {
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, "0");
  const minutes = now.getMinutes().toString().padStart(2, "0");
  const seconds = now.getSeconds().toString().padStart(2, "0");
  return `[${hours}:${minutes}:${seconds}]`;
}

// Función que obtiene el precio y el cambio porcentual de la API y actualiza el badge
function fetchPriceAndUpdateBadge() {
  console.log(`${getTimestamp()} [Alarm] Iniciando fetchPriceAndUpdateBadge...`);
  fetch(DEXSCREENER_API_URL)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      const price = data.pair?.priceUsd; // Precio en USD
      const priceChangeH1 = data.pair?.priceChange?.h1; // Cambio en la última hora
      if (price !== undefined && priceChangeH1 !== undefined) {
        console.log(
          `${getTimestamp()} [Alarm] Precio obtenido: ${price}, Cambio en 1h: ${priceChangeH1}%`
        );

        // Configura el texto del badge con el precio actual
        const badgeText = parseFloat(price).toFixed(4).replace(/^0\./, "");
        chrome.action.setBadgeText({ text: badgeText });

        // Cambia el color del badge según el cambio en 1h
        if (priceChangeH1 > 0) {
          chrome.action.setBadgeBackgroundColor({ color: "#00FF00" }); // Verde si positivo
        } else if (priceChangeH1 < 0) {
          chrome.action.setBadgeBackgroundColor({ color: "#FDA622" }); // Rojo si negativo
        } else {
          chrome.action.setBadgeBackgroundColor({ color: "#000000" }); // Negro si sin cambio
        }
      } else {
        console.error(`${getTimestamp()} [Alarm] No se encontraron datos válidos en la respuesta.`);
      }
    })
    .catch((error) => {
      console.error(`${getTimestamp()} [Alarm] Error al obtener el precio:`, error);
    });
}

// Listener para alarmas
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "updatePrice") {
    fetchPriceAndUpdateBadge();
  }
});

// Crear o restablecer la alarma al instalar o iniciar la extensión
chrome.runtime.onInstalled.addListener(() => {
  console.log(`${getTimestamp()} [Alarm] Crypto Price Tracker instalado. Configurando alarma.`);
  chrome.alarms.create("updatePrice", { periodInMinutes: 0.50 }); // Cada 15 segundos
  fetchPriceAndUpdateBadge(); // Llamada inicial
});

chrome.runtime.onStartup.addListener(() => {
  console.log(`${getTimestamp()} [Alarm] Crypto Price Tracker activado al iniciar el navegador.`);
  chrome.alarms.create("updatePrice", { periodInMinutes: 0.50 });
  fetchPriceAndUpdateBadge(); // Llamada inicial
});

// Listener para abrir URLs al clicar el ícono de la extensión
chrome.action.onClicked.addListener(() => {
  const urls = [
        "https://app.hyperliquid.xyz/join/TUXS", // URL 1
        "https://dexscreener.com/hyperliquid/0x13ba5fea7078ab3798fbce53b4d0721c", // URL 2
  ];

  // Obtén las pestañas actuales para calcular el índice final
  chrome.tabs.query({ currentWindow: true }, (tabs) => {
    const lastIndex = tabs.length; // Última posición en las pestañas actuales

    // Abre cada URL en la última posición
    urls.forEach((url, i) => {
      chrome.tabs.create({ url: url, index: lastIndex + i });
    });
  });
});
